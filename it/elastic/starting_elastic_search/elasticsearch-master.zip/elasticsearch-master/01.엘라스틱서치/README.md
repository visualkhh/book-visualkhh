#1. 엘라스틱서치

그림 1.1 엘라스틱서치 사용 사례: http://www.elasticsearch.org/case-studies


그림 1.3 아파치 솔라: https://lucene.apache.org/solr/


그림 1.4 몽고DB: http://www.mongodb.org/
