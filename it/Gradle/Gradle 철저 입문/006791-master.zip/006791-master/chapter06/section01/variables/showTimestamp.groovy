import java.sql.Timestamp

date = new Date()

Timestamp ts = new Timestamp(date.getTime())
println ts