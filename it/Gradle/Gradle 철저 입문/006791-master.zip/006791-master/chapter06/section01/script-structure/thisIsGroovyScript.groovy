  class Descriptor {
    String show() {
      '*** 이것은 Groovy 스크립트 입니다. ***'
    }
  }
  println new Descriptor().show()