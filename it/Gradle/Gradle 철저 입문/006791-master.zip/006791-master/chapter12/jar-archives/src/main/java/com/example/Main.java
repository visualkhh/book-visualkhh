package com.example;

public class Main {
  public static final void main(String[] args) {
    System.out.println("Hello, world!");
  }
}

