package com.example;

/**
 * サンプルのメインクラスです
 */
public class Main {

  /**
   * @param args コマンドライン引数
   */
  public static void main(String[] args) {
      System.out.println("Hello, World!");
  }
}

