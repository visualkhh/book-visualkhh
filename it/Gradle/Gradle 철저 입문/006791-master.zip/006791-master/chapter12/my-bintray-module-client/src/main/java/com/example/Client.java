package com.example;

public class Client {
    public static void main(String[] args) {
        Main.main(args);
    }
}

