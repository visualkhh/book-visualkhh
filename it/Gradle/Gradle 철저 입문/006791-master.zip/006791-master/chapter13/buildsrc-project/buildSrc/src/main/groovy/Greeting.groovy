// buildSrc/src/main/groovy/Greeting.groovy
class Greeting {
  String content
}

