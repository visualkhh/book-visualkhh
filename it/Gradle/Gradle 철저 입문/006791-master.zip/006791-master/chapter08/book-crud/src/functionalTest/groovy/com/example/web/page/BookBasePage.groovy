package com.example.web.page

import geb.Page

class BookBasePage extends Page {
	
	static final String BOOK_URL = 'http://localhost:8080/book-crud'
}
