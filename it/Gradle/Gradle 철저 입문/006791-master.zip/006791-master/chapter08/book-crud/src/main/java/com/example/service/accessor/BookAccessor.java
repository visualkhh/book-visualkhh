package com.example.service.accessor;

public interface BookAccessor {

	String getId();
	String getTitle();
	String getIsbn();
}
