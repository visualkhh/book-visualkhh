package com.example.web.page

class ListPage extends BookBasePage {
	static url = "$BOOK_URL/list"
	
	static at = {
		title == "샘플 애플리케이션 | 서적 목록 화면"
	}
}
