package com.example.web.page

class CreatePage extends BookBasePage {
	static url = "$BOOK_URL/create"
	
	static at = {
		title == "샘플 애플리케이션 | 서적 등록 화면"
	}
}
