INSERT INTO book (title, isbn) VALUES ('Grails徹底入門', '9784798117362');  
INSERT INTO book (title, isbn) VALUES ('VMware徹底入門', '9784798128429');
INSERT INTO book (title, isbn) VALUES ('Hadoop徹底入門', '9784798129648');
