package com.example.suite.categories;

public interface IntegrationTests {

}
