package com.example.suite.categories;

public interface UnitTests {

}
