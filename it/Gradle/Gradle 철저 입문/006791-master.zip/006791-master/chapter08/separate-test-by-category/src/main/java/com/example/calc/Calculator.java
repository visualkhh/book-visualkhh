package com.example.calc;

public interface Calculator {
	int calculate(int code, int hansu, boolean tsumo, boolean peace);
}
