package com.example;

public class Parameter {
	public int code;
	public int hansu;
	public boolean tsumo;
	public boolean peace;
}
