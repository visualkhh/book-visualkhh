package com.example.suite.categories;

public class SlowTests {

}
