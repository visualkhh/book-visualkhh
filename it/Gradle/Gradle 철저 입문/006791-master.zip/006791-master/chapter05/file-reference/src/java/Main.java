import com.example.Something;

public class Main {
    public static void main(String[] args) {
        Something s = new Something();
        System.out.println(s.getName());
    }
}
