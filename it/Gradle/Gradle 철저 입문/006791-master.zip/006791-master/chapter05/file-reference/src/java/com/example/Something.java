package com.example;

public class Something {

    public String getName() {
        return "something";
    }
}
