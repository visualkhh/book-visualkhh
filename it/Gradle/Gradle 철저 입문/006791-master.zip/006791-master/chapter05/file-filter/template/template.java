package com.example.bean;

/**
 * VALUE_OBJECT_NAME。
 * 자동 생성에 의한 정형적인 bean 클래스
 *
 * @author AUTHOR_NAME
 */
public class VALUE_OBJECT_NAME {
	private String name;
	private String value;

	public void VALUE_OBJECT_NAME() {}
	public void VALUE_OBJECT_NAME(String name, String value) {
		this.name = name;
		this.value = value;
	}

	public String getName() {
		return name;
	}

	public String getValue() {
		return value;
	}
}