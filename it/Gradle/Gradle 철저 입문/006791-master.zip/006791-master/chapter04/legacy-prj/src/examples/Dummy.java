package examples;

class Dummy {}
