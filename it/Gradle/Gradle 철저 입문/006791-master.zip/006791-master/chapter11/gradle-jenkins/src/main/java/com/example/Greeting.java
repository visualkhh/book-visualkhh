package com.example;

public class Greeting {
    public String sayHello() {
        return "Hello World!!";
    }

    public String sayGoodbye() {
        return new String("bye bye World!!");
    }


}
