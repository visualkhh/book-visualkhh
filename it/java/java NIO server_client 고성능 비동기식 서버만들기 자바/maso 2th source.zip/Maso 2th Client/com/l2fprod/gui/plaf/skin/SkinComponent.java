package com.l2fprod.gui.plaf.skin;

/**
 * Skin Component.
 * <br>
 *
 * @author $Author: l2fprod $
 * @version $Revision: 1.1.1.1 $, $Date: 2000/07/26 19:31:06 $
 */
public interface SkinComponent {

    boolean status();

    public boolean installSkin(javax.swing.JComponent c);

}
