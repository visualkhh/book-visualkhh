from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities

caps = DesiredCapabilities.INTERNETEXPLORER
caps['ignoreProtectedModeSettings'] = True

driver = webdriver.Ie(capabilities=caps)
#driver = webdriver.Chrome()
driver.get("file:///C:/selenium/index.html")
print driver.title;



element = driver.find_element_by_xpath("/html/body/a")
element.click()





try:
    WebDriverWait(driver, 3).until(EC.alert_is_present(),
                                   'Timed out waiting for PA creation ' +
                                   'confirmation popup to appear.')

    alert = driver.switch_to_alert()
    alert.accept()
    print "alert accepted"
except TimeoutException:
    print "no alert"






#print driver.page_source
#driver.close()