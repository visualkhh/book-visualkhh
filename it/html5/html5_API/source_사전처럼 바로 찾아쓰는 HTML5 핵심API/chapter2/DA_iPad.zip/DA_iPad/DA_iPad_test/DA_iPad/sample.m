//
//  sample.m
//  DA_iPad
//
//  Created by junjun on 11. 4. 8..
//  Copyright 2011 raction. All rights reserved.
//

#import "sample.h"


@implementation sample

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
- (void)loadView 
{	
	[super loadView];
	self.view.backgroundColor = [UIColor grayColor];
    //self.navigationController.navigationBarHidden = YES;
	
	UIButton* temp = [UIButton buttonWithType:UIButtonTypeRoundedRect];
	[temp setFrame:CGRectMake(0, 100, 100, 50)];
	//[temp setTitle:SLOT_ID forState:UIControlStateNormal];
	[temp addTarget:self action:@selector(checkType) forControlEvents:UIControlEventTouchUpInside];
    
	Ad = [[DA_iPad_Manager alloc] initWithSlotID:@"1000007391" :0];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(checkType) name:@"DA_iPad_LoadComplete" object:nil];
    
	self.view.frame = CGRectMake(0, 0, 768, 1024);
}
-(void)checkType
{
	[self.view addSubview:Ad.view];
	
	NSLog(@"%@",Ad.type);
}
- (void)viewWillAppear:(BOOL)animated 
{
    // listen for keyboard hide/show notifications so we can properly adjust the table's height
	[super viewWillAppear:animated];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillShow:)
                                                 name:UIKeyboardWillShowNotification
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillHide:)
                                                 name:UIKeyboardWillHideNotification
                                               object:nil];
}
- (void)keyboardWillShow:(NSNotification *)aNotification 
{
	if ([Ad.type isEqualToString:@"DACPA02T"]){
		[Ad showKeyBoard];
	}	
}
- (void)keyboardWillHide:(NSNotification *)aNotification
{
	if ([Ad.type isEqualToString:@"DACPA02T"]){
		[Ad hideKeyBoard];
    }
}
-(void)willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration
{
	
}
-(void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation
{
	[Ad updateRotate];
}

/*
 // Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
 - (void)viewDidLoad {
 [super viewDidLoad];
 
 }
 */


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
//	if ([Ad.type isEqualToString:@"DACPA01T"] || [Ad.type isEqualToString:@"DACPA02T"]) {
//		//세로만 지원
//		return (interfaceOrientation == UIInterfaceOrientationPortrait);
//	}
    return YES;
}
- (void)dealloc
{
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

\

@end
