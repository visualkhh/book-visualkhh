//
//  DA_iPadAppDelegate.h
//  DA_iPad
//
//  Created by junjun on 11. 4. 8..
//  Copyright 2011 raction. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface DA_iPadAppDelegate : NSObject <UIApplicationDelegate> {


}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
