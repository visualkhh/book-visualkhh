//
//  sample.h
//  DA_iPad
//
//  Created by junjun on 11. 4. 8..
//  Copyright 2011 raction. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DA_iPad_Manager.h"

@interface sample : UIViewController {
        DA_iPad_Manager* Ad;
}

@end
