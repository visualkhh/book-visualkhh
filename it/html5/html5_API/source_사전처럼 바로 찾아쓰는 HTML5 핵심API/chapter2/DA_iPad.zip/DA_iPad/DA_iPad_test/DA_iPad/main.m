//
//  main.m
//  DA_iPad
//
//  Created by junjun on 11. 4. 8..
//  Copyright 2011 raction. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[])
{
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, @"DA_iPadAppDelegate");
    [pool release];
    return retVal;
}
