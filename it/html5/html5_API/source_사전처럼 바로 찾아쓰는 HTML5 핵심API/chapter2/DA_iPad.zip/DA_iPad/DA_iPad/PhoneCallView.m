
#import "PhoneCallView.h"


@implementation PhoneCallView


- (void)loadView {
	[super loadView];
	//self.view.backgroundColor = [UIColor redColor];
	//[self setUI];
}
//전달 받은 값으로 기본정보를 설정하고 화면을 구성한다.
-(void)setUI:(NSString*)phoneNumber :(NSString*)name :(NSString*)address :(NSString*)info :(UIImage*)headImage
{
    
	m_info = info;
	m_name = name;
	m_phoneNumber = phoneNumber;
	m_address = address;
	//NSLog(@"%@ , %@ , %@ , %@", m_info,m_name,m_phoneNumber,m_address);
	
	//상단의 회사 로고 이미지는 여기서 설정 한다.
	UIImageView* head = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"callNdmHead.png"]];
	head.frame = CGRectMake((320-272)/2, 0+20, 272, 44);
	[self.view addSubview:head];
	
	UIImageView* top = [[UIImageView alloc] initWithImage:headImage];
	top.frame = CGRectMake((320-272)/2+5, 0+30, 250, 30);
	[self.view addSubview:top];
	
	UIButton* btnX = [UIButton buttonWithType:UIButtonTypeCustom];
	[btnX setImage:[UIImage imageNamed:@"callNdmBtnX.png"] forState:UIControlStateNormal];
	[btnX setFrame:CGRectMake(272-5, 20, 55/2, 55/2)];
	[btnX addTarget:self action:@selector(closeView) forControlEvents:UIControlEventTouchUpInside];
	[self.view addSubview:btnX];
	
	UIImageView* bg = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"DM_bg.png"]];
	bg.frame = CGRectMake((320-272)/2, 44+20, 258, 250);
	[self.view addSubview:bg];
	
	UIImageView* form = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"callForm_bg.png"]];
	form.frame = CGRectMake((320-272)/2+3, 46+20, 252, 140);
	[self.view addSubview:form];
	
	UIImageView* phoneNumBG = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"phoneNumber_bg.png"]];
	phoneNumBG.frame = CGRectMake((320-272)/2+20, 190+20, 216, 28);
	[self.view addSubview:phoneNumBG];
	
	//회사 이름등등의 정보는 설정은 아래와 같다. 
	UILabel* nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 42+20, 310, 26)];
	[nameLabel setText:m_name];
	[nameLabel setTextColor:[UIColor whiteColor]];
	[nameLabel setTextAlignment:UITextAlignmentCenter];
	[nameLabel setBackgroundColor:[UIColor clearColor]];
	[self.view addSubview:nameLabel]; 
	
	UILabel* addressLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 80+20, 310, 30)];
	[addressLabel setText:m_address];
	[addressLabel setTextAlignment:UITextAlignmentCenter];
	[addressLabel setBackgroundColor:[UIColor clearColor]];
	[self.view addSubview:addressLabel]; 
	
	UILabel* infoLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 120+20, 310, 40)];
	[infoLabel setText:m_info];
	[infoLabel setTextAlignment:UITextAlignmentCenter];
	[infoLabel setBackgroundColor:[UIColor clearColor]];
	[self.view addSubview:infoLabel]; 
	
	UILabel* phoneNumberLabel = [[UILabel alloc] initWithFrame:CGRectMake((320-272)/2+20, 190+20, 216, 28)];
	[phoneNumberLabel setText:m_phoneNumber];
	[phoneNumberLabel setTextAlignment:UITextAlignmentCenter];
	[phoneNumberLabel setBackgroundColor:[UIColor clearColor]];
	[self.view addSubview:phoneNumberLabel]; 
    
    //취소 버튼과 전화 걸기 버튼에 대한 설정
	
	UIButton* btnCancle = [UIButton buttonWithType:UIButtonTypeCustom];
	[btnCancle setImage:[UIImage imageNamed:@"btn_cancel.gif"] forState:UIControlStateNormal];
	btnCancle.frame = CGRectMake((320-272)/2+15, 235+20, 107, 35);
	[self.view addSubview:btnCancle];
	[btnCancle addTarget:self action:@selector(closeView) forControlEvents:UIControlEventTouchUpInside];
	
	UIButton* btnCall = [UIButton buttonWithType:UIButtonTypeCustom];
	[btnCall setImage:[UIImage imageNamed:@"btn_call.gif"] forState:UIControlStateNormal];
	btnCall.frame = CGRectMake((320-272)/2+110+25, 235+20, 106, 35);
	[self.view addSubview:btnCall];
	[btnCall addTarget:self action:@selector(call) forControlEvents:UIControlEventTouchUpInside];
	
	self.view.frame = CGRectMake(0, 40+20, 320, 480);
	
}
-(void)call
{
	//전화 걸기 버튼을 누르면 전달받은 번호에서 숫자만을 남기고, 그 숫자의 번호로 전화를 건다.
	NSMutableString* strCall = [[NSMutableString alloc] initWithCapacity:13];
	[strCall setString:m_phoneNumber];
	[strCall replaceOccurrencesOfString:@"-" withString:@"" options:(NSStringCompareOptions)nil range:NSMakeRange(0, [strCall length])];
	NSLog(@"%@",strCall);
	[[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"tel://%@", strCall]]];
	[[NSNotificationCenter defaultCenter] postNotificationName:@"CLICK2" object:nil];
}
//현재는 사용되지 않음
//가로 세로 전환시 사용되는 부분
-(void)updateRotate:(BOOL)isVertical{
	if (isVertical){
		//세로
		//self.view.frame = CGRectMake(0, 40, 320, 480);
	}
	else{
		//가로
		//self.view.frame = CGRectMake(80, 40, 320, 480);
	}
	
}
//화면이 나타날때 애니메이션
-(void)openView:(BOOL)isVertical
{
	
	self.view.alpha = 1;
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration:0.5];
	if (isVertical) 
	{
		self.view.transform = CGAffineTransformMakeTranslation(0, -380);
	}
	else
	{
		self.view.transform = CGAffineTransformMakeTranslation(0, -380);
	}
	
	[UIView setAnimationTransition:UIViewAnimationCurveEaseInOut forView:self.view cache:YES];	
	[UIView commitAnimations];
	
	
}
//닫기 버튼을 눌렀을때 사라지는 부분 구현
-(void)closeView
{
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration:0.5];
	self.view.transform = CGAffineTransformMakeTranslation(0, 0);
	
	[UIView setAnimationTransition:UIViewAnimationCurveEaseInOut forView:self.view cache:YES];	
	self.view.alpha = 0;
	[UIView commitAnimations];
	[[NSNotificationCenter defaultCenter] postNotificationName:@"closeAd" object:nil];
}
- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
