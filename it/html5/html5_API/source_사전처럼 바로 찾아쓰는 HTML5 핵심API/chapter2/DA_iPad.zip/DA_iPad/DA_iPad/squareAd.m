
#import "squareAd.h"


@implementation squareAd

//닫기 버튼 배치									//{{x,y},{width,height}}
CGRect closeButton_Position_Horizontal_square = {{768-10-40 , 10} , { 40 , 40 }};
CGRect closeButton_Position_Vertical_square = {{768-10-40 , 10} , { 40 , 40 }};

//바로가기 버튼 배치
CGRect goButton_Position_Horizontal_square = {{768-10-80 , 768-40-10-20} , { 80 , 40 }};
CGRect goButton_Position_Vertical_square = {{768-10-80 , 768-40-10-20 } , { 80 ,  40 }};


//전면 배너일 경우의 프레임 사이즈 320:480 = 480:720
CGRect mainFrame_Horizontal_square = {0,0,768,768};
CGRect mainFrame_Vertical_square = {0,0,768,768};


- (void)loadView {                                                        
	[super loadView];
	
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
	return YES;
}
//가로세로 전환시에 호출됨
-(void)updateRotate:(BOOL)isVertical
{
	
	if (isVertical) 
	{
		//세로
		mainScroll.frame = CGRectMake(0, 0, 768, 768);
		mainScroll.contentSize = mainFrame_Vertical_square.size;
		mainAd.frame=mainFrame_Vertical_square;
		
		btnClose.frame = closeButton_Position_Vertical_square;
		btnGo.frame = goButton_Position_Vertical_square;
	}
	else 
	{
		//가로
		mainScroll.frame = CGRectMake(0, 0, 480, 480);
		mainAd.frame = mainFrame_Horizontal_square;
		mainScroll.contentSize =  mainFrame_Horizontal_square.size;
		
		btnClose.frame = closeButton_Position_Horizontal_square;
		btnGo.frame = goButton_Position_Horizontal_square;
	}
	
}
//광고 이미지를 셋팅하여 초기화 하고 화면을 구성 한다. 초기 화면이 셋팅될때 가로 인지 세로인지에 따라 위치가 다르다.
-(void)setAd:(UIImage*)image
{
	if (UIDeviceOrientationIsLandscape([UIDevice currentDevice].orientation)) 
	{//가로
		self.view = [[UIView alloc] initWithFrame:mainFrame_Horizontal_square];
	}
	else 
	{//세로
		self.view = [[UIView alloc] initWithFrame:mainFrame_Vertical_square];
	}
	
	if (UIDeviceOrientationIsLandscape([UIDevice currentDevice].orientation)) 
	{//가로
		mainScroll = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, 480, 480)];
		mainAd = [[UIImageView alloc] initWithImage:image];
		
		mainScroll.contentSize =  mainFrame_Horizontal_square.size;
		mainScroll.backgroundColor = [UIColor clearColor];				
		mainAd.frame = mainFrame_Horizontal_square;
	}
	else 
	{//세로
		mainScroll = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, 768, 768)];
		mainAd = [[UIImageView alloc] initWithImage:image];
		
		mainScroll.contentSize = mainFrame_Vertical_square.size;
		mainScroll.backgroundColor = [UIColor clearColor];				
		mainAd.frame=mainFrame_Vertical_square;
	}
	
	[mainScroll addSubview:mainAd];
	[self.view addSubview:mainScroll];
}
//열기 버튼 과 닫기 버튼의 위치를 지정하고 화면에 보이도록 한다.
-(void)setUI
{
	btnClose = [UIButton buttonWithType:UIButtonTypeCustom];
	btnGo = [UIButton buttonWithType:UIButtonTypeCustom];
	
	[btnClose setImage:[UIImage imageNamed:@"btn_close.png"] forState:UIControlStateNormal];
	[btnGo setImage:[UIImage imageNamed:@"btn_go.png"] forState:UIControlStateNormal];
	
	//방향 체크
	UIDeviceOrientation orientation = [UIApplication sharedApplication].statusBarOrientation; 
	if (orientation == UIDeviceOrientationLandscapeRight || orientation == UIDeviceOrientationLandscapeLeft) 
	{
		btnClose.frame = closeButton_Position_Horizontal_square;
		btnGo.frame = goButton_Position_Horizontal_square;
	}
	else 
	{
		btnClose.frame = closeButton_Position_Vertical_square;
		btnGo.frame = goButton_Position_Vertical_square;
		
	}
	
	//닫기 버튼과 바로가기 버튼에 대한 함수연결
	[btnClose addTarget:self action:@selector(closeView) forControlEvents:UIControlEventTouchUpInside];
	[btnGo addTarget:self action:@selector(goAd) forControlEvents:UIControlEventTouchUpInside];
	
	[mainScroll addSubview:btnGo];
	[mainScroll addSubview:btnClose];
	
}

//화면이 나타날때의 애니메이션
-(void)openView:(BOOL)isVertical
{

	self.view.alpha = 1;
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration:0.5];
	if (isVertical) 
	{
		self.view.transform = CGAffineTransformMakeTranslation(0, -768);
	}
	else
	{
		self.view.transform = CGAffineTransformMakeTranslation(0, -768);
	}
	
	[UIView setAnimationTransition:UIViewAnimationCurveEaseInOut forView:self.view cache:YES];	
	[UIView commitAnimations];


}
//화면이 닫힐 경우의 애니메이션
-(void)closeView
{
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration:0.5];
	self.view.transform = CGAffineTransformMakeTranslation(0, 0);
	
	[UIView setAnimationTransition:UIViewAnimationCurveEaseInOut forView:self.view cache:YES];	
	self.view.alpha = 0;
	[UIView commitAnimations];
	[[NSNotificationCenter defaultCenter] postNotificationName:@"closeAd" object:nil];

}
//바로 가기 버튼을 눌렀을때 호툴
-(void)goAd
{
	[[NSNotificationCenter defaultCenter] postNotificationName:@"OpenBrowser" object:nil];
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
