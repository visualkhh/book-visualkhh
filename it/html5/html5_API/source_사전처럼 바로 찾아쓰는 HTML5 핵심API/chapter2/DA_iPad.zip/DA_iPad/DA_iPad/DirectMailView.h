

#import <UIKit/UIKit.h>

@interface DirectMailView : UIViewController<UITextFieldDelegate,UITextViewDelegate> {


	
	UITextField* nameField;     //이름입력
	UITextField* phoneNumField; //전화번호 입력창
	UITextField* addressField;  //주소 입력 창
	UITextField* etcField;      //기타 정보 입력창
	
	NSString* companyName;      //회사 이름 값
	NSString* companyIntro;     //회사 정보 값
	NSString* sendAddress;      //회사 주소 값
	
}
-(void)setUI:(NSString*)name :(NSString*)introduce :(NSString*)mailAddress :(UIImage*)headImage;
-(void)sendMail;
-(void)openView:(BOOL)isVertical;
-(void)updateRotate:(BOOL)isVertical;
-(void)setTextField:(CGRect)rect fontSize:(CGFloat)fontSize tag:(int)tag;
//-(void)setTextView:(CGRect)rect fontSize:(CGFloat)fontSize tag:(int)tag;
-(void)keyBordOpen:(BOOL)isVertical;
-(void)keyBordClose:(BOOL)isVertical;
@end
