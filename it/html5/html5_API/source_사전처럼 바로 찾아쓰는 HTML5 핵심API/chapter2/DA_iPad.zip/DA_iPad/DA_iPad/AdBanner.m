

#import "AdBanner.h"


@implementation AdBanner

//광고의 타입별로 하단의 띠배너를 생성하기 위한 초기화 함수
//광고의 타입과 롤링배너를 위한 이미지 배열을 생성해둠.
-(id)initWithAdType:(NSString*)stradType
{
	adType = stradType;
	arrAdImages = [[NSMutableArray alloc] init];
	return self;
}
//하단의 띠배너에 이미지를 넘겨 받고 그 이미지로 띠배너 광고를 셋팅
-(void)setAdImage:(UIImage*)image
{
    //배너를 저장하는 이미지 공간에 넘겨 받은 이미지를 셋팅
	adImage = [[UIImageView alloc] initWithImage:image];
	[adImage setImage:image];
    //토스트 배너의 경우는 다른 광고보다 세로 폭이 넓으므로 세로 값을 다르게 준다.
	if ([adType isEqualToString:@"DACPM04"]) 
	{
		adImage.frame = CGRectMake(0, 0, 320, 108);
	}
	else
	{
		adImage.frame = CGRectMake(0, 0, 768, 72);
	}
    //현재 adBanner의 뷰를 광고 이미지뷰로 설정
	self.view = adImage;
}
//롤링배너는 이미지가 여러개 이기때문에 배열로 넘겨 받는다.넘어오는 값은 이미지의 URL이다.
-(void)setAdImages:(NSMutableArray*)Images
{
    //이미지의 갯수를 받음
	maxImages = [Images count];
    //이미지의 갯수 만큼 이미지 URL로 이미지를 생성하여 초기화 함수에서 생성해둔 이미지 배열에 할당한다.
	for (int i = 0; i<maxImages; i++) 
	{
		UIImageView* temp = [[UIImageView alloc] initWithImage:[UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[Images objectAtIndex:i]]]]];
		
		temp.frame = CGRectMake(0, 0, 768, 72);
		
		temp.tag = i+1;
		//NSLog(@"index L %d %@",i,[Images objectAtIndex:i]);
		[arrAdImages addObject:temp];
	}
    //할당 완료후 첫번째 배너이미지를 보이도록 한다.
	[self.view addSubview:[arrAdImages objectAtIndex:0]];
	
	
    //롤링 이미지 효과를 주기위해 전 화면과 후 화면을 할당 해놓는다
    //전 이미지는 사라지고 후 이미지는 나타난다.
	frontImage = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 768, 72)];
	backImage = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 768, 0)];
	
	
}
//롤링 이미지 시작을 위한 타이머
//첫번째 인자의수는 인터벌 타임이다. 
//여서서는 타이머를 시작하기위해 1초뒤에 changeView 함수가 시작되게 하기위한 진입점이다.
//외부에서 호출
-(void)timerStart
{

	NSTimer* timer = [NSTimer scheduledTimerWithTimeInterval:1			
													  target:self							  
													selector:@selector(changeView:)							  
													userInfo:nil								
													 repeats:NO];	
	//0은 첨에 나오니까
	//k=1;
}
//롤링 이미지 효과를 주기위한 함수 
//타이머에 의해 호출된다. 
-(void)changeView:(NSTimer*) timer
{
    //커스텀 애니메이션을 위한 호출 
	[UIView beginAnimations:nil context:NULL];
    //설정 한 초 만큼의 시간동안 애니메이션이 실행된다. 값을 늘리면 애니메이션이 느려지고 작아질수록 빨라 진다.
	[UIView setAnimationDuration:0.75];
	[UIView setAnimationDelegate:self];
    //애니메이션이 완료되면 호출 되는 함수를 설정
	[UIView setAnimationDidStopSelector:@selector(viewChangeEnd)];
	
	
    //실제 이미지를 움직이는 부분
    //k는 현재 보이고 있는 배너의 인덱스
	int a = k;
    //다음 배너의 인덱스
	int b = k+1;
    //마지막 이미지라면 첫번째 이미지를 다음이미지에 할당
	if (k == maxImages-1) {
		b = 0;
	}
	//배열에 있는 인덱스로 앞,뒤 이미지를 셋팅
	[frontImage setImage:[[arrAdImages objectAtIndex:a] image]];
	[backImage setImage:[[arrAdImages objectAtIndex:b] image]];
	
    //이미지를 보이도록한다.
	[self.view addSubview:frontImage];
	[self.view addSubview:backImage];
	
    //최종적으로 도달해야 하는 역역을 설정.
    //-(void)setAdImages:(NSMutableArray*)Images 함수의 앞뒤이미지의 영역과 비교하면 이해가 되실꺼임
	frontImage.frame = CGRectMake(0, 72, 768, 0);
	backImage.frame = CGRectMake(0, 0, 768, 72);
	
    //애니메이션종료를 위한 호출
	[UIView setAnimationTransition:UIViewAnimationTransitionNone forView:self.view cache:YES];
	[UIView commitAnimations];	
}
//애니메이션이 끝나면 호출되는 함수
-(void)viewChangeEnd
{
    //애니메이션이 끝나면 배너가 넘어가 있는 상태이기 때문에 배너의 인덱스를 넘겨줍니다.
	k++;
    //만일 넘어간 인덱스가 이미지의 갯수와 같다면 첫번째 인덱스로 설정해 줍니다. 
    //인덱스는 0부터 시작이고 이미지 갯수는 1부터 시작이기 때문에 
    //아래의 경우는 마지막 이미지 다음이라는 얘기입니다.
	if (k == maxImages) k=0;
    //이미지를 교체해 주기 위해 버퍼를 한개 마련하고 거기다 뒷이미지를 둡니다.
	UIImageView* temp = backImage;
    //앞에 있던 이미지를 뒤의 이미지로 둡니다.
	backImage = frontImage;
    //버퍼에 있던 이미지를 앞으로 옮깁니다.
	frontImage = temp;
	
    //이미지의 영역을 원래대로 돌려 놓습니다.
	frontImage.frame = CGRectMake(0, 0, 768, 72);
	backImage.frame = CGRectMake(0, 0, 768, 0);
    //여기서 다시 타이머를 돌립니다. 
    // 앞서 -(void)timerStart에서는 1초 뒤에 호출됐지만 여기서는 5초에 한번씩 changeView함수를 호출 합니다.
	NSTimer* timer2 = [NSTimer scheduledTimerWithTimeInterval:5					
													   target:self							  
													 selector:@selector(changeView:)							  
													 userInfo:nil								
													  repeats:NO];
}
//현재의 배너 인덱스를 반환
-(int)getBannerIndex
{
	return k;
}
//배너가 터치되면 호출됩니다.
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	[[NSNotificationCenter defaultCenter] postNotificationName:@"OpenBrowser" object:nil];
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
    [super dealloc];
}


@end
