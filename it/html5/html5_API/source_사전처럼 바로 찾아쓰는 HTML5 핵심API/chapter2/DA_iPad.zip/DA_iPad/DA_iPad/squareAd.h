

#import <UIKit/UIKit.h>


@interface squareAd : UIViewController {

	UIScrollView* mainScroll; //터치확장배너가 스크롤할경우 //현재 사용되지 않음
	
	UIButton* btnClose;         //닫기 버튼
	UIButton* btnGo;            // 바로 가기 버튼
	
	UIImageView* mainAd;        //광고 이미지 

}

-(void)setUI;
-(void)setAd:(UIImage*) image;

-(void)updateRotate:(BOOL)isVertical;

-(void)openView:(BOOL)isVertical;
-(void)closeView;

@end
