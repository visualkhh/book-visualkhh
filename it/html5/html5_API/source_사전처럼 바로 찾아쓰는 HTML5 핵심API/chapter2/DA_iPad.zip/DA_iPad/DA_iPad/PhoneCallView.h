
#import <UIKit/UIKit.h>


@interface PhoneCallView : UIViewController {

    
	NSString* m_name;           //회사 이름
	NSString* m_phoneNumber;    //회사 전화번호
	NSString* m_address;        //회사 주소
	NSString* m_info;           //회사 정보
	
}
-(void)setUI:(NSString*)phoneNumber :(NSString*)name :(NSString*)address :(NSString*)info :(UIImage*)headImage;
-(void)updateRotate:(BOOL)isVertical;
-(void)closeView;
-(void)openView:(BOOL)isVertical;
@end
