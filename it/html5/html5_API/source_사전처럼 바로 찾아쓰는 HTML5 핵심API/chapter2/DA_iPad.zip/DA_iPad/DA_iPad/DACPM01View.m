

#import "DACPM01View.h"


@implementation DACPM01View

//닫기 버튼 배치									//{{x,y},{width,height}}
CGRect closeButton_Position_Horizontal = {{768-10-40 , 10} , { 40 , 40 }};
CGRect closeButton_Position_Vertical = {{768-10-40 , 10} , { 40 , 40 }};

//바로가기 버튼 배치
CGRect goButton_Position_Horizontal = {{768-10-80 , 1024-40-10-20} , { 80 , 40 }};
CGRect goButton_Position_Vertical = {{768-10-80 , 1024-40-10-20 } , { 80 ,  40 }};


//전면 배너일 경우의 프레임 사이즈 320:480 = 480:720
CGRect mainFrame_Horizontal = {80,0,768,1024};
CGRect mainFrame_Vertical = {0,0,768,1024};


//초기 화면 셋팅 가로세로에 따라 위치와 크기가 다름
- (void)loadView {                                                        
	[super loadView];
	
	isRotation = NO;
	if (UIDeviceOrientationIsLandscape([UIDevice currentDevice].orientation)) 
	{//가로
		self.view = [[UIView alloc] initWithFrame:mainFrame_Horizontal];
	}
	else 
	{//세로
		self.view = [[UIView alloc] initWithFrame:mainFrame_Vertical];
	}
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
	return YES;
}
-(void)willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration{
	if (!isRotation) {
		isRotation=YES;
		return;
	}
	UIDeviceOrientation orientation = [UIApplication sharedApplication].statusBarOrientation; 
	if (orientation == UIDeviceOrientationLandscapeRight || orientation == UIDeviceOrientationLandscapeLeft) 
	{
		//이전 상태가 가로였으면 세로로 표시		
		mainScroll.frame = CGRectMake(0, 0, 768, 1024);
		mainScroll.contentSize = mainFrame_Vertical.size;
		mainScroll.backgroundColor = [UIColor clearColor];	
		
		mainAd.frame=mainFrame_Vertical;
		
		btnClose.frame = closeButton_Position_Vertical;
		btnGo.frame = goButton_Position_Vertical;

	}
	else 
	{
		//이전 상태가 세로였으면 가로로 표시		
		mainScroll.frame = CGRectMake(0, 0, 1024, 768);		
		mainScroll.contentSize =  mainFrame_Horizontal.size;
		mainScroll.backgroundColor = [UIColor clearColor];	
		
		mainAd.frame = mainFrame_Horizontal;
		
		btnClose.frame = closeButton_Position_Horizontal;
		btnGo.frame = goButton_Position_Horizontal;
	}
	
}
//가로세로 전환이 일어날때 호출
-(void)updateRotate
{
	//self.view.backgroundColor = [UIColor redColor];
	UIDeviceOrientation orientation = [UIApplication sharedApplication].statusBarOrientation; 
	if (orientation == UIDeviceOrientationLandscapeRight || orientation == UIDeviceOrientationLandscapeLeft) 
	{
		//이전 상태가 가로였으면 세로로 표시		
		//mainScroll.frame = CGRectMake(0, 0, 320, 480-20);
		mainScroll.frame = CGRectMake(0, 0, 768, 1024);
		mainScroll.contentSize = mainFrame_Vertical.size;
		mainScroll.backgroundColor = [UIColor clearColor];	
		
		//mainAd.frame=;
		self.view.frame = mainFrame_Vertical;
		
		btnClose.frame = closeButton_Position_Vertical;
		btnGo.frame = goButton_Position_Vertical;
		
	}
	else 
	{
		//이전 상태가 세로였으면 가로로 표시
		//mainScroll.frame = CGRectMake(0, 0, 480, 320-20);
		mainScroll.frame = CGRectMake(0, 0, 1024, 768);
		mainScroll.contentSize =  mainFrame_Horizontal.size;
		mainScroll.backgroundColor = [UIColor clearColor];	
		self.view.frame = mainFrame_Horizontal;
		//mainAd.frame = mainFrame_Horizontal;
		
		btnClose.frame = closeButton_Position_Horizontal;
		btnGo.frame = goButton_Position_Horizontal;
	}	
}
//전달 받은 이미지로 광고를 셋팅 
-(void)setAd:(UIImage*)adImage
{
		
	if (UIDeviceOrientationIsLandscape([UIDevice currentDevice].orientation)) 
	{//가로

		mainScroll = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, 1024, 768)];
		
		mainAd = [[UIImageView alloc] initWithImage:adImage];
		
		mainScroll.contentSize =  mainFrame_Horizontal.size;
		mainScroll.backgroundColor = [UIColor clearColor];				
	}
	else 
	{//세로
		mainScroll = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, 768, 1024)];
		mainAd = [[UIImageView alloc] initWithImage:adImage];
		
		mainScroll.contentSize = mainFrame_Vertical.size;
		mainScroll.backgroundColor = [UIColor clearColor];				
	}
	mainAd.frame = CGRectMake(0, 0, 768, 1024);
	[mainScroll addSubview:mainAd];
	[self.view addSubview:mainScroll];
	[self setUI];
	
}
//열기버튼 닫기 버튼을 붙임.
-(void)setUI
{
	btnClose = [UIButton buttonWithType:UIButtonTypeCustom];
	btnGo = [UIButton buttonWithType:UIButtonTypeCustom];
	
	[btnClose setImage:[UIImage imageNamed:@"btn_close.png"] forState:UIControlStateNormal];
	[btnGo setImage:[UIImage imageNamed:@"btn_go.png"] forState:UIControlStateNormal];
	
	//방향 체크
	UIDeviceOrientation orientation = [UIApplication sharedApplication].statusBarOrientation; 
	if (orientation == UIDeviceOrientationLandscapeRight || orientation == UIDeviceOrientationLandscapeLeft) 
	{
		btnClose.frame = closeButton_Position_Horizontal;
		btnGo.frame = goButton_Position_Horizontal;
	}
	else 
	{
		btnClose.frame = closeButton_Position_Vertical;
		btnGo.frame = goButton_Position_Vertical;
	}
	
	[btnClose addTarget:self action:@selector(closeView) forControlEvents:UIControlEventTouchUpInside];
	[btnGo addTarget:self action:@selector(goAd) forControlEvents:UIControlEventTouchUpInside];
	
	[mainScroll addSubview:btnGo];
	[mainScroll addSubview:btnClose];
	
}
//닫기 버튼을 누르면 닫히는 부분 
-(void)closeView
{
	[[NSNotificationCenter defaultCenter] postNotificationName:@"closeAd" object:nil];	
}
//URL여는 부븐
-(void)goAd
{
	[[NSNotificationCenter defaultCenter] postNotificationName:@"OpenBrowser" object:nil];
}


- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
