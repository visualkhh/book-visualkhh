

#import <UIKit/UIKit.h>


@interface DACPM01View : UIViewController {

    //배너를 스크롤 하기 위한스크롤 가로일경우에 적용
	UIScrollView* mainScroll;
    //배너 닫기 버튼
	UIButton* btnClose;
    //바로가기버튼
	UIButton* btnGo;
	
    //링크 URL
	NSString* strAdURL;
    //광고 이미지
	UIImageView* mainAd;
	BOOL isRotation;
}
-(void)setAd:(UIImage*)adImage;
-(void)setUI;
-(void)closeView;
-(void)goAd;
-(void)updateRotate;
@end
