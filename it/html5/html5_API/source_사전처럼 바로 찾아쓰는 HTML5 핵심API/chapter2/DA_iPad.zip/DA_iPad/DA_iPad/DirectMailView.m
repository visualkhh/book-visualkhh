
#import "DirectMailView.h"


@implementation DirectMailView

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/


// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
	[super loadView];
	//self.view.backgroundColor = [UIColor redColor]; 
	//[self setUI];
	
	
	//self.view.backgroundColor = [UIColor blueColor];
}
//전달 받은 값으로 초기 값을설정 하고 화면 을 구성한다.
-(void)setUI:(NSString*)name :(NSString*)introduce :(NSString*)mailAddress :(UIImage*)headImage 
{
    //전달 받은 값 설정
	companyName = name;
	sendAddress = mailAddress;
	companyIntro = introduce;
	//image
	UIImageView* head = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"callNdmHead.png"]];
	head.frame = CGRectMake((320-272)/2, 0+20, 272, 44);
	[self.view addSubview:head];
	
    //상단의 회사 로고 이미지는 여기서 설정 된다.
	UIImageView* top = [[UIImageView alloc] initWithImage:headImage];
	top.frame = CGRectMake((320-272)/2+5, 0+30, 250, 30);
	[self.view addSubview:top];
	
	UIButton* btnX = [UIButton buttonWithType:UIButtonTypeCustom];
	[btnX setImage:[UIImage imageNamed:@"callNdmBtnX.png"] forState:UIControlStateNormal];
	[btnX setFrame:CGRectMake(272-5, 20, 55/2, 55/2)];
	[btnX addTarget:self action:@selector(closeView) forControlEvents:UIControlEventTouchUpInside];
	[self.view addSubview:btnX];
	
	UIImageView* bg = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"DM_bg.png"]];
	bg.frame = CGRectMake((320-272)/2, 44+20, 258, 319);
	[self.view addSubview:bg];
	
	UIImageView* form = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"mailForm_bg.png"]];
	form.frame = CGRectMake((320-272)/2+3, 46+20, 252, 281);
	[self.view addSubview:form];
	

	UILabel* nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 42+20, 310, 26)];
	[nameLabel setText:companyName];
	[nameLabel setTextColor:[UIColor whiteColor]];
	[nameLabel setTextAlignment:UITextAlignmentCenter];
	[nameLabel setBackgroundColor:[UIColor clearColor]];
	[self.view addSubview:nameLabel];
	
	UILabel* introLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 42+20+65, 310, 26)];
	[introLabel setText:companyIntro];
	[introLabel setTextColor:[UIColor blackColor]];
	[introLabel setTextAlignment:UITextAlignmentCenter];
	[introLabel setBackgroundColor:[UIColor clearColor]];
	[self.view addSubview:introLabel];
	
	
	UIButton* btnCancle = [UIButton buttonWithType:UIButtonTypeCustom];
	[btnCancle setImage:[UIImage imageNamed:@"btn_cancel.gif"] forState:UIControlStateNormal];
	btnCancle.frame = CGRectMake((320-272)/2+15, 281+5+30+20, 107, 35);
	[self.view addSubview:btnCancle];
	[btnCancle addTarget:self action:@selector(closeView) forControlEvents:UIControlEventTouchUpInside];
	
	UIButton* btnSend = [UIButton buttonWithType:UIButtonTypeCustom];
	[btnSend setImage:[UIImage imageNamed:@"btn_mail.gif"] forState:UIControlStateNormal];
	btnSend.frame = CGRectMake((320-272)/2+110+25, 281+5+30+20, 106, 35);
	[self.view addSubview:btnSend];
	[btnSend addTarget:self action:@selector(sendMail) forControlEvents:UIControlEventTouchUpInside];
	
    //사용자가 입력하기 위한 텍스트 필드를 셋팅 
	//textField
	[self setTextField:CGRectMake(120, 175+20, 140, 20) 
			  fontSize:10 
				   tag:0];
		
	[self setTextField:CGRectMake(120, 175+20+20, 140, 20) 
			  fontSize:10 
				   tag:1];

	[self setTextField:CGRectMake(120, 175+40+20, 140, 20) 
			  fontSize:10 
				   tag:2];
		
	[self setTextField:CGRectMake(120, 175+60+20, 140, 50) 
			  fontSize:10 
				   tag:3];	
//hhg	[self setTextField:CGRectMake(120, 175+80, 140, 20) 
//			  fontSize:10 
//				   tag:4];
    
    //초기 값은 공백이다
	
	nameField.text = @"";
	phoneNumField.text = @"";
	addressField.text = @"";
	etcField.text = @"";
}
#pragma mark -
#pragma mark mail
//베일은 전송하는 부분, 아이폰의 기본 메일 어플을 실행 시킨다.
-(void)sendMail
{
	NSString *strBody = [[NSString alloc] initWithFormat:@"이름 : %@\n전화번호 : %@\n주소 : %@\n기타문의 : %@"
						 , nameField.text, phoneNumField.text, addressField.text, etcField.text];
	strBody = [strBody stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
	
	NSString *url = [NSString stringWithFormat:@"mailto:%@?cc=&subject=%@&body=%@", sendAddress, companyName, strBody];
	NSLog(@"메일 전송 정보: %@",url);
	[[UIApplication sharedApplication] openURL:[NSURL URLWithString: url]];
}
#pragma mark -
#pragma mark UITextFieldDelegate
//텍스트 필드 안에서 Done 버튼이 눌리면 키보드가 사라지게 하는 부분
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
	// the user pressed the "Done" button, so dismiss the keyboard
	[textField resignFirstResponder];
	return YES;
}
//텍스트 필드 안에서 입력되는 글자를 확인하는 부분
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string 
{
	int maxLength;
	if (textField.tag==0) {//이름은 10자 이하 
		maxLength =10;
	}
	else if (textField.tag==1) //전화 번호는 12자 이하
	{
		maxLength =12;
		
		if ([string length] > 0) //전화 번호의 길이체크 부분
		{
			
            //numberFormatter는 자주 사용할 예정이므로 아래 코드를 이용해서 생성해둬야함
			
            NSNumberFormatter* numberFormatter = [[NSNumberFormatter alloc] init];
			
            [numberFormatter setNumberStyle:NSNumberFormatterDecimalStyle];
			
            NSNumber* candidateNumber = [numberFormatter numberFromString:string];
			
            if(candidateNumber == nil) 
			{				
                return NO;				
            }
			
            if ([[candidateNumber stringValue] compare:string] !=  NSOrderedSame) 
			{
                return NO;
            }
		}
	}
	else if (textField.tag==2) {//기타 정보 입력은 50그자 이하
		maxLength =50;
	}
	//string은 현재 키보드에서 입력한 문자 한개를 의미한다.
	
	if(string && [string length] && ([textField.text length] >= maxLength))   return NO;
	
	return TRUE;
}
//텍스트 필드를 셋팅한다. 텍스트 필드의 테그값으로 각각으 필드에 대해서 처리한다.
//태그값에 따른 필드 
//0 : 이름, 1 : 전화 번호 3: 기타 정보
-(void)setTextField:(CGRect)rect fontSize:(CGFloat)fontSize tag:(int)tag
{
	UITextField* textID;// = [[UITextField alloc] initWithFrame:rect];			
	if (tag == 0) {
		nameField = [[UITextField alloc] initWithFrame:rect];
		textID = nameField;
		
	}
	if (tag == 1) {
		phoneNumField = [[UITextField alloc] initWithFrame:rect];
		textID = phoneNumField;
	}
	if (tag == 2) {
		addressField  = [[UITextField alloc] initWithFrame:rect];
		textID = addressField;
	}
	if (tag == 3) {
		etcField  = [[UITextField alloc] initWithFrame:rect];
		textID = etcField;
	}
	//textID.borderStyle = UITextBorderStyleBezel;
	textID.textColor = [UIColor blackColor];
	textID.font = [UIFont systemFontOfSize:fontSize];
	
//텍스트 필드에 대한 기본적인 셋팅 
    //배경 컬러, 키보드 타입, 엔터 버튼의 타입 등등을 정한다.
	
	textID.backgroundColor = [UIColor whiteColor];
	textID.autocorrectionType = UITextAutocorrectionTypeNo;	// no auto correction support
	textID.borderStyle = UITextBorderStyleRoundedRect;
	textID.keyboardType = UIKeyboardTypeDefault;	// use the default type input method (entire keyboard)
	textID.returnKeyType = UIReturnKeyDone;
	textID.clearButtonMode = UITextFieldViewModeWhileEditing;	// has a clear 'x' button to the right
	textID.tag = tag;
	//[textID textRectForBounds:rect];
	//textID.text = (NSString*)[MyDefaults objectForKey:@"id_Value"];
	
	textID.delegate = self;	// let us be the delegate so we know when the keyboard's "Done" button is pressed
	[self.view addSubview:textID];
}
/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/
#pragma mark -
#pragma mark ViewChange
//현재는 사용되지 않음.
//회전했을경우의 셋팅
-(void)updateRotate:(BOOL)isVertical{
	if (isVertical){
		//세로
		self.view.frame = CGRectMake(0, 0, 320, 480);
	}
	else{
		//가로
		self.view.frame = CGRectMake(80, 0, 320, 480);
	}
	
}
//화면이 나타날때 애니메이션
-(void)openView:(BOOL)isVertical
{
	
	self.view.alpha = 1;
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration:0.5];
	if (isVertical) 
	{
		self.view.transform = CGAffineTransformMakeTranslation(0, -440);
	}
	else
	{
		self.view.transform = CGAffineTransformMakeTranslation(0, -440);
	}
	
	[UIView setAnimationTransition:UIViewAnimationCurveEaseInOut forView:self.view cache:YES];	
	[UIView commitAnimations];
	
	
}
//닫기 버튼이 눌렸을떄 사라지는 부분
-(void)closeView
{
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration:0.5];
	self.view.transform = CGAffineTransformMakeTranslation(0, 0);
	
	[UIView setAnimationTransition:UIViewAnimationCurveEaseInOut forView:self.view cache:YES];	
	self.view.alpha = 0;
	[UIView commitAnimations];
	[[NSNotificationCenter defaultCenter] postNotificationName:@"closeAd" object:nil];
	
}
//키보드가 나타날때 에 대한 처리 
-(void)keyBordOpen:(BOOL)isVertical
{
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration:0.5];
	if (isVertical) 
	{
		[self.view superview].transform = CGAffineTransformMakeTranslation(0, -150);
	}
	else 
	{
		[self.view superview].transform = CGAffineTransformMakeTranslation(0, -150);
	}
	
	[UIView setAnimationTransition:UIViewAnimationCurveEaseInOut forView:[self.view superview] cache:YES];	
	[UIView commitAnimations];
}
//키보드가 사라질때의 처리
-(void)keyBordClose:(BOOL)isVertical
{
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration:0.5];
	[self.view superview].transform = CGAffineTransformMakeTranslation(0, 0);
	[UIView setAnimationTransition:UIViewAnimationCurveEaseInOut forView:[self.view superview] cache:YES];	
	[UIView commitAnimations];
}
- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
