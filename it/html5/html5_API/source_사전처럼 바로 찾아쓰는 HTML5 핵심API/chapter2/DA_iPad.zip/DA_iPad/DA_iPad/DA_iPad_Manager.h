//
//  DA_iPad_Manager.h
//  DA_iPad
//
//  Created by junjun on 11. 4. 8..
//  Copyright 2011 raction. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AdBanner.h"
#import "squareAd.h"
#import "PhoneCallView.h"
#import "DirectMailView.h"
#import "DACPM01View.h"
typedef enum {
	etNone = 0,
	etItem
} eElementType;
@interface DA_iPad_Manager : UIViewController<NSXMLParserDelegate> {
	float PositionY; //배너의 y포지션의 위치를 얼마나 위로 올릴것인가.
	int bannerHeight;
	NSString* u_ip;
    //파싱
	BOOL isSendData; //서버에 전송하는 것인지 파싱이 필요한지 판별
	NSURLConnection *xmlConnection;
	eElementType elementType;
	
	NSMutableString *xmlValue;
	NSMutableData *receiveData;
	
	//광고에 대한 기본 정보
	//////////////////////////////////////////////////
	NSString* m_slotID;
	NSString* m_adType;
	
	NSMutableArray *info;
	NSString* adId;
	NSString* houseAD;
	NSString* interval;
	NSString* slotID;
	NSString* type;
	
	NSMutableArray *banners;
	NSString* banner1;
	NSString* banner2;
	NSString* banner3;
	NSString* banner4;
	NSString* banner5;
	
	NSString* url1;
	NSString* url2;
	NSString* url3;
	NSString* url4;
	NSString* url5;
	
	NSString* text1;
	NSString* text2;
	NSString* text3;
	NSString* text4;
	NSString* text5;
	//////////////////////////////////////////////////
	
	
	//배너들
	//////////////////////////////////////////////////
	AdBanner* adBanner;         //하단 띠배너
	DACPM01View* DACPM01;       //전면 배너
	
    //2차 배너들
	squareAd* secondAd1;        //터치확장 배너 
	PhoneCallView* secondAd2;   //콜배너 
	DirectMailView* secondAd3;  //DM배너
	
    //배너의 열린 여부 판단
	BOOL isAdOpen;
    
    
	
	
	//toast
    float toastAdHeight;//토스트 배너의 높이 위치 조정을 위해 필요함.
    UIButton* btnOpen;// 토스트 배너의 열기 버튼
	NSTimer* timer;//토스트 배너 자동으로 닫히기 위한 타이머
	BOOL isToastOpen; //토스트 배의 열린 여부 판단
	
	
}

-(id)initWithSlotID:(NSString*)strSlotID;
-(id)initWithSlotID:(NSString*)strSlotID :(float)Positiony;


- (NSString *)deviceIPAdress;

-(void)showKeyBoard;
-(void)hideKeyBoard;

-(void)OpenBrowser;
-(void)parseXML:(NSString *)requestURL node:(NSString *)strNode;

-(NSString*)getNSStringFromUnicode:(NSString*)strUnicode;
-(void)setAd;
-(void)openAd;
- (BOOL)requestUrl:(NSString *)url;

-(void)toast;
-(void)updateRotate;

-(void)openDACPM01;
-(void)ONLOAD;
-(void)CLICK1;
-(void)CLICK2;
-(void)COMP1;
-(void)COMP2;

@property (nonatomic,retain) NSString* u_ip;

@property (nonatomic,retain) AdBanner* adBanner;
@property (nonatomic,retain) NSString* adId;
@property (nonatomic,retain) NSString* houseAD;
@property (nonatomic,retain) NSString* interval;
@property (nonatomic,retain) NSString* slotID;
@property (nonatomic,retain) NSString* type;

@property (nonatomic,retain) NSString* banner1;
@property (nonatomic,retain) NSString* banner2;
@property (nonatomic,retain) NSString* banner3;
@property (nonatomic,retain) NSString* banner4;
@property (nonatomic,retain) NSString* banner5;

@property (nonatomic,retain) NSString* url1;
@property (nonatomic,retain) NSString* url2;
@property (nonatomic,retain) NSString* url3;
@property (nonatomic,retain) NSString* url4;
@property (nonatomic,retain) NSString* url5;

@property (nonatomic,retain) NSString* text1;
@property (nonatomic,retain) NSString* text2;
@property (nonatomic,retain) NSString* text3;
@property (nonatomic,retain) NSString* text4;
@property (nonatomic,retain) NSString* text5;
@end
