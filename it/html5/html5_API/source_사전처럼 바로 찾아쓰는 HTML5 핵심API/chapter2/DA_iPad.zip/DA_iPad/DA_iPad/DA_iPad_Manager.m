    //
//  DA_iPad_Manager.m
//  DA_iPad
//
//  Created by junjun on 11. 4. 8..
//  Copyright 2011 raction. All rights reserved.
//

#import "DA_iPad_Manager.h"
#import "IPAddress.h"


@implementation DA_iPad_Manager
@synthesize adId,houseAD,interval,slotID,type,banner1,banner2,banner3,banner4,banner5,url1,url2,url3,url4,url5,text1,text2,text3,text4,text5,adBanner,u_ip;

//서버에 통지하기 위한 URL
#define url_delivery	@"http://203.247.155.58:8001/smp/ad/sysNavi/reqNormalDelivery.adm?"
#define url_confirm		@"http://203.247.155.58:8001/smp/ad/sysNavi/confirmDelivery.adm?"

//PositionY에 위로 올릴 값을 넣어서 초기화 합니다.
//SlotID값으로 초기화 합니다.
#pragma mark -
#pragma mark Ip주소 얻기
- (NSString *)deviceIPAdress 
{
	InitAddresses();
	GetIPAddresses();
	GetHWAddresses();
	return [NSString stringWithFormat:@"%s",ip_names[1]];
}
#pragma mark -
#pragma mark 배너 초기화 
//하단으로 부터 위로 올릴값을 할당하여 초기화 합니다.
-(id)initWithSlotID:(NSString*)strSlotID :(float)Positiony{
	
	self = [self initWithSlotID:strSlotID];
	PositionY = Positiony;
	return self;
}

//slotID값을 할당하여 초기화 합니다.
-(id)initWithSlotID:(NSString*)strSlotID{	
	m_slotID = strSlotID;
    PositionY = 0;
	u_ip = [[self deviceIPAdress] retain];
	//self.view.backgroundColor = [UIColor redColor];
	[self parseXML:
	 [NSString stringWithFormat:@"%@slotId=%@&eventType=ONLOAD&deviceId=%@&deviceType=SP&osType=IO&osVer=&model=&browserNm=&deviceTime=&ip=%@&areaCd=&imgXSize=768&imgYSize=1024",
	  url_delivery, strSlotID,[[UIDevice currentDevice] uniqueIdentifier],u_ip]
			  node:@"ads"];
//	[self parseXML:
//	 [NSString stringWithFormat:@"http://183.109.124.217:2010/lgapi/xml.jsp?slotId=%@",strSlotID]
//			  node:@"ads"];
    
	isSendData = NO;
    //노티피 케이션을 등록 
    // 해당 메세지가 발생하면 셀렉터에 등록된 함수가 실행됩니다.
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(closeAd) name:@"closeAd" object:nil];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(OpenBrowser) name:@"OpenBrowser" object:nil];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(CLICK2) name:@"CLICK2" object:nil];
	
	return self;
}

#pragma mark -
#pragma mark 서버 커넥션
//서버에 xml문서를 요청해서 파싱 시작
-(void)parseXML:(NSString *)requestURL node:(NSString *)strNode{
	
    //전달 받은 URL로 커넥션을 요청해서 데이타를 받아 옵니다.
	NSURLConnection* connection = [[NSURLConnection alloc] initWithRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:requestURL]] delegate:self];
	
    //파싱된 XML값이 스트링의 형태로 저장돨 공간
	xmlValue = [[NSMutableString alloc] init];
    //요청한 URL로 부터 받은 데이터가 저장될 공간
	receiveData = [[NSMutableData alloc] init];
	
    //커넥션이 에러났을 경우 발생
	if (connection == nil)
		NSLog(@"Connect error");
	else{
		//커넥션이 됐으면 서버와 통신 중임을 표시
		[UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
	}
	
}

//데이터를 받아올때마다 데이타를 저장 합니다. 
//만일 서버에 보고를 위한 것이라면 데이타를 저장하지 않습니다,
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
	if (isSendData) {
		return;
	}
	[receiveData appendData:data];
}

//서버로 부터 데이타를 전부 받으면 호출 됩니다.
- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
	if (isSendData) {
		return;
	}
    //받은 데이타를 파서를 통해 파싱을 시작합니다.
	NSXMLParser *parser = [[NSXMLParser alloc] initWithData:receiveData];
	
	[parser setDelegate:self];
	[parser parse];//파싱 시작
	[parser release];
	//파싱이 끝나면 통신종료
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
}

//에러가 났을경우 호출
- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
	NSLog(@"Connect error: %@", [error localizedDescription]);    
	
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
}

#pragma mark -
#pragma mark xmlParser //파싱의 구현

//NSXMLParser가 입력된 데이타 값으로 파싱을 하던중에 엘리먼트 요소를 만나면 호출 됩니다.  
- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict {
    //서버에 보고를 위한것이면 리턴
    if (isSendData) {
		return;
	}
    //엘리먼트 이름이 ads이거나 ad라면 파싱을할때 우리가 원하는 요소이므로 이것을 받습니다.
	if ([elementName isEqualToString:@"ads"]||[elementName isEqualToString:@"ad"]) 
        elementType = etItem;
	
    //ad안에는 광고의 기본정보가 들어 있습니다. 이것들을 저장해 둡니다.
	if	([elementName isEqualToString:@"ad"]){
		
		self.adId = [attributeDict valueForKey:@"adId"];
		self.houseAD = [attributeDict valueForKey:@"houseAD"];
		self.interval = [attributeDict valueForKey:@"interval"]; 
		self.type =[attributeDict valueForKey:@"type"]; 
	}
	
	//NSLog(@"%@",attributeDict);
    //엘리먼트 요소를 담을 xmlValue의 값을 초기화 합니다.
	[xmlValue setString:@""];
}

//우리가 원하는 요소라면 xmlValue에 값을 저장합니다. 캐릭터를 하나하나 돌면서 다 받습니다.
- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string {
    if (elementType == etItem) {
        [xmlValue appendString:string];
    }
}

//엘리먼트의 끝요소가 나오면 호출됩니다. 
- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName {
    if (elementType != etItem)//우리가 원하는 요소가 아니면 처리하지 않습니다.
        return;
	if (isSendData) {//서버에 보고하기 위한것이면 처리하지 않습니다.
		return;
	}
	NSLog(@"elementName :  %@",elementName);
	NSLog(@"elementValue :  %@",[NSString stringWithString:xmlValue]);
	
    //아래는 각 엘리먼트의 속성명에 따라 그에 맞는 변수에 값을 할당하는 소스 입니다.
	if ([elementName isEqualToString:@"banner1"]) self.banner1 = [NSString stringWithString:xmlValue];
	else if ([elementName isEqualToString:@"banner2"]) self.banner2 = [NSString stringWithString:xmlValue];
	else if ([elementName isEqualToString:@"banner3"]) self.banner3 = [NSString stringWithString:xmlValue];
	else if ([elementName isEqualToString:@"banner4"]) self.banner4 = [NSString stringWithString:xmlValue];
	else if ([elementName isEqualToString:@"banner5"]) self.banner5 = [NSString stringWithString:xmlValue];
	else if ([elementName isEqualToString:@"url1"]) self.url1 = [NSString stringWithString:xmlValue];
	else if ([elementName isEqualToString:@"url2"]) self.url2 = [NSString stringWithString:xmlValue];
	else if ([elementName isEqualToString:@"url3"]) self.url3 = [NSString stringWithString:xmlValue];
	else if ([elementName isEqualToString:@"url4"]) self.url4 = [NSString stringWithString:xmlValue];
	else if ([elementName isEqualToString:@"url5"]) self.url5 = [NSString stringWithString:xmlValue];
	else if ([elementName isEqualToString:@"text1"]) self.text1 = [NSString stringWithString:xmlValue];
	else if ([elementName isEqualToString:@"text2"]) self.text2 = [NSString stringWithString:xmlValue];
	else if ([elementName isEqualToString:@"text3"]) self.text3 = [NSString stringWithString:xmlValue];
	else if ([elementName isEqualToString:@"text4"]) self.text4 = [NSString stringWithString:xmlValue];
	else if ([elementName isEqualToString:@"text5"]) self.text5 = [NSString stringWithString:xmlValue];
	else if ([elementName isEqualToString:@"ads"]) //마지막요소이면 지금 까지 저장흔 값을 체크하고 알맞게 조정하여 다시 저장 합니다.
	{
        //배너를 담을 배열입니다.
		banners = [[[NSMutableArray alloc] init] retain];
        //배너의 공백 문자를 없애 줍니다.
		self.banner1=[self.banner1 stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
		self.banner2=[self.banner2 stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
		self.banner3=[self.banner3 stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
		self.banner4=[self.banner4 stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
		self.banner5=[self.banner5 stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
		
        // 배너가 비어있다면 저장하지 않습니다.
		if (![self.banner1 isEqualToString:@""]) [banners addObject:self.banner1];
		if (![self.banner2 isEqualToString:@""]) [banners addObject:self.banner2];
		if (![self.banner3 isEqualToString:@""]) [banners addObject:self.banner3];
		if (![self.banner4 isEqualToString:@""]) [banners addObject:self.banner4];
		if (![self.banner5 isEqualToString:@""]) [banners addObject:self.banner5];
		
        //서버에서 보내준 값을받았으니 이를 토대로 광고를 셋팅합니다. 
		[self setAd];
        //셋팅이 완료되면 광고 로드가 끝났다는 통지를 보냅니다. 
        //이 통지는 실제 어플을 개발하는 부분에서 필요합니다.
		[[NSNotificationCenter defaultCenter] postNotificationName:@"DA_iPad_LoadComplete" object:nil];
	}
	
    
}

#pragma mark -
#pragma mark  setAd //광고별 배너 설정
//기본 배너 사이즈 :37
//롤링배너 => 여러장의 이미지로 초기화
//터치 확장, DM, Call => 배너 한장 

//토스트 배너 사이즈 : 108
//토스트 배너 => 열기 닫기 버튼, 토스트 모션 
-(void)setAd{
	
	UIDeviceOrientation orientation = [UIApplication sharedApplication].statusBarOrientation; 
	adBanner = [[AdBanner alloc] initWithAdType:self.type];
	//NSLog(@"%@",self.type);
	//광고별 셋팅
	if ([self.type isEqualToString:@"DACPM01"]) //전면배너
	{
        //전면 배너를 생성합니다.
		DACPM01 = [[DACPM01View alloc] init];
        //파싱된 배너의 URL로 부터 이미지를 생성합니다.
		UIImage* adImage = [[UIImage alloc] initWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:self.banner1]]];
		
        //전면 배너에 이미질를 셋팅 합니다.
		[DACPM01 setAd:adImage];
		//[DACPM01 setUI];
        //전면배너가 보이도록 합니다.
		[self.view addSubview:DACPM01.view];
        //전면 배너의 크기와 위치를 설정 합니다. 가로모드일 경우와 세로모드일 경우가 다릅니다.
		UIDeviceOrientation orientation = [UIApplication sharedApplication].statusBarOrientation; 
		if (orientation == UIDeviceOrientationLandscapeRight || orientation == UIDeviceOrientationLandscapeLeft) 
		{
			//가로
			self.view.frame = CGRectMake(0, self.view.bounds.size.height,  480,320);
		}
		else {
			self.view.frame = CGRectMake(0, self.view.bounds.size.height, 320, 480);
		}
		
        //전면 배너를 오픈 합니다.
		[self openDACPM01];
		
	}
	else if ([self.type isEqualToString:@"DACPM03"])//롤링배너
	{
		bannerHeight =  72;
		[adBanner setAdImages:banners];
		adBanner.view.frame = CGRectMake(0, 0, 768, bannerHeight);
		[adBanner timerStart];
	}
	else if([self.type isEqualToString:@"DACPM04"])//토스트 배너
	{
		UIImage* adImage = [[UIImage alloc] initWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:self.banner1]]];
		bannerHeight = 216+30;
		[adBanner setAdImage:adImage];
		adBanner.view.frame = CGRectMake(0, 30, 768, bannerHeight-30);
		
		btnOpen= [UIButton buttonWithType:UIButtonTypeCustom];
		btnOpen.frame = CGRectMake(768-50, 0, 50, 30);
		[btnOpen setImage:[UIImage imageNamed:@"btn_toast_open.png"] forState:UIControlStateNormal];
		[btnOpen addTarget:self action:@selector(toast) forControlEvents:UIControlEventTouchUpInside];
		[self.view addSubview:btnOpen];
		isToastOpen = NO;
		[self toast];
	}
	else if([self.type isEqualToString:@"DACPC01"]||[self.type isEqualToString:@"DACPA01T"]||[self.type isEqualToString:@"DACPA02T"])//기타 배너
	{
		UIImage* adImage = [[UIImage alloc] initWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:self.banner1]]];
		bannerHeight = 72;
		[adBanner setAdImage:adImage];
		adBanner.view.frame = CGRectMake(0, 0, 768, bannerHeight);
	}
	else {
		self.view.frame = CGRectMake(0, 0, 0, 0);
	}

	if(orientation == UIDeviceOrientationPortrait)
	{ 
		if(![self.type isEqualToString:@"DACPM04"]) self.view.frame = CGRectMake(0,1024-bannerHeight-PositionY,  768, bannerHeight);
	}
	
	[self.view addSubview:adBanner.view];
	
	[self COMP1];
}

#pragma mark -
#pragma mark bannerHandle //광고별  핸들링
//토스트 배너의 열고 닫는 애니메이션
-(void)toast{
    //이전에 타이머가 돌고 있으면 정지 시킵니다.
	if (timer) {
		[timer invalidate];
		[timer release];
		timer = nil;
	}
    
    //초기 토스트 배너의 위치는 아래쪽에 숨겨져 있습니다.
	//adBanner.view.frame = CGRectMake(0, 30, 320, toastAdHeight);
	self.view.frame = CGRectMake(0,1024-30-PositionY,  768, bannerHeight);
    //애니메이션을 시작합니다.
	[UIView beginAnimations:nil context:NULL];
    //0.2초에 걸쳐 애니메이션 됩니다.
	[UIView setAnimationDuration:0.2];
	
    CGRect rect;
	rect = [[UIApplication sharedApplication] statusBarFrame];
	
    //토스트 배너가 열려있으면 닫고 닫혀 있으면 열립니다.
	if(!isToastOpen)
	{
		UIDeviceOrientation orientation = [UIApplication sharedApplication].statusBarOrientation; 
		if (orientation == UIDeviceOrientationLandscapeLeft || orientation == UIDeviceOrientationLandscapeRight) 
		{
			self.view.frame = CGRectMake(128,768-bannerHeight-PositionY,  768, bannerHeight);
		}
		else 
		{
			self.view.frame = CGRectMake(0,1024-bannerHeight-PositionY,  768, bannerHeight);
		}
		
		
		[btnOpen setImage:[UIImage imageNamed:@"btn_toast_close.png"] forState:UIControlStateNormal];
	}
	else 
	{
		UIDeviceOrientation orientation = [UIApplication sharedApplication].statusBarOrientation; 
		if (orientation == UIDeviceOrientationLandscapeLeft || orientation == UIDeviceOrientationLandscapeRight) 
		{
			self.view.frame = CGRectMake(128,768-rect.size.width-30-PositionY,  768, bannerHeight);
		}
		else 
		{
			self.view.frame = CGRectMake(0,1024-rect.size.height-30-PositionY,  768, bannerHeight);
		}
		//self.view.transform = CGAffineTransformMakeTranslation(0, 0);
		[btnOpen setImage:[UIImage imageNamed:@"btn_toast_open.png"] forState:UIControlStateNormal];
	}
	
	[UIView setAnimationTransition:UIViewAnimationCurveEaseInOut forView:self.view cache:YES];	
	[UIView commitAnimations];
	isToastOpen = !isToastOpen;
	
    //토스트 배너가 열려 있는 경우라면 5초 뒤에 닫아야 하기 때문에 타이머를 호출 합니다.
	if (isToastOpen) 
	{
		timer = [[NSTimer scheduledTimerWithTimeInterval:5
												  target:self
												selector:@selector(toast)
												userInfo:nil
												 repeats:NO]retain];	
	}
	
}

//배너 터치로 브라우저가 열릴때
//롤링배너는 링크가 여러개
-(void)OpenBrowser{
	NSString* temp = @"http://";
	
	if ([self.type isEqualToString:@"DACPM03"]) {
		int index = [adBanner getBannerIndex];
		//NSLog(@"%d",index); 
		
		if (index == 0) {
			temp = [temp stringByAppendingString:self.url1];
		}
		else if(index == 1)
		{
			temp = [temp stringByAppendingString:self.url2];
		}
		else if(index == 2)
		{
			temp = [temp stringByAppendingString:self.url3];
		}
		else if(index == 3)
		{
			temp = [temp stringByAppendingString:self.url4];
		}
		else if(index == 4)
		{
			temp = [temp stringByAppendingString:self.url5];
		}
	}
	else 
	{
		temp = [temp stringByAppendingString:self.url1];
		
	}
	[[UIApplication sharedApplication] openURL:[NSURL URLWithString:temp]];
	[self CLICK1];
}

//광고 영역 터치 되었을때의 처리
//토스트 배너, 터치 확장, Call, DM배너터치시 2차 배너 열기
//토스트 => URL이동 
//DM,Call, 터치 확장 배너 => 2차 배너 열기
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
	if ([self.type isEqualToString:@"DACPM04"]) //토스트 배너 
	{
		[self OpenBrowser];
	}
	//else if ([self.type isEqualToString:@"DACPC01"]||[self.type isEqualToString:@"DACPA01T"||[self.type isEqualToString:@"DACPA02T"]]) 
	//터치 확장 배너 //call배너 
	else 
	{
		[self CLICK1];
		[self openAd];
		
	}
	
	
}

//2차 광고 열기위한설정
//각 2차 광고별 UI설정 및 나타나는 애니메이션 호출
-(void)openAd{
    //이미광고가 열려 있다면 처리 하지 않습니다.
	if (isAdOpen) return;
	isAdOpen = YES;
	
	if ([self.type isEqualToString:@"DACPC01"]){
		secondAd1 = [[squareAd alloc] init];
        //NSLog(@"%@",[banners objectAtIndex:1]);
		
        UIImage* adImage = [[UIImage alloc] initWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:self.banner2]]];
		[secondAd1 setAd:adImage];
		[secondAd1 setUI];
		
		
		[[self.view superview] addSubview:secondAd1.view];
		
		UIDeviceOrientation orientation = [UIApplication sharedApplication].statusBarOrientation; 
		if (orientation == UIDeviceOrientationLandscapeLeft || orientation == UIDeviceOrientationLandscapeRight)
		{//가로
			//맨 밑바닥에 안보이게 셋팅
			secondAd1.view.frame = CGRectMake(0, 768-PositionY, 768, 768);
			[secondAd1 openView:NO];
		}
		else 
		{//세로
			secondAd1.view.frame = CGRectMake(0, 1024-PositionY, 768, 768);
			[secondAd1 openView:YES];
		}
		
		//[self COMP2];
	}
	else if([self.type isEqualToString:@"DACPA01T"]){
		secondAd2 = [[PhoneCallView alloc] init];
		UIImage* adImage = [[UIImage alloc] initWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:self.banner2]]];
		[secondAd2 setUI:self.text4 :self.text1 :self.text2 :self.text3 :adImage];
		
		[[self.view superview] addSubview:secondAd2.view];
		
		UIDeviceOrientation orientation = [UIApplication sharedApplication].statusBarOrientation; 
		if (orientation == UIDeviceOrientationLandscapeLeft || orientation == UIDeviceOrientationLandscapeRight)
		{//가로
			//맨 밑바닥에 안보이게 셋팅
			secondAd2.view.frame = CGRectMake(0, 768-PositionY, 768, 768);
			[secondAd2 openView:NO];
		}
		else 
		{//세로
			secondAd2.view.frame = CGRectMake(0, 1024-PositionY, 768, 768);
			[secondAd2 openView:YES];
		}
		
		[secondAd2 openView:YES];
		
	}
	else if([self.type isEqualToString:@"DACPA02T"])
	{
		secondAd3 = [[DirectMailView alloc] init];
		//NSLog(@"%@ %@",self.text1,self.text2);
		UIImage* adImage = [[UIImage alloc] initWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:self.banner2]]];
		[secondAd3 setUI:self.text1 :self.text2 :self.text3 :adImage];
		
		[[self.view superview] addSubview:secondAd3.view];
		
		UIDeviceOrientation orientation = [UIApplication sharedApplication].statusBarOrientation; 
		if (orientation == UIDeviceOrientationLandscapeLeft || orientation == UIDeviceOrientationLandscapeRight)
		{//가로
			//맨 밑바닥에 안보이게 셋팅
			secondAd3.view.frame = CGRectMake(0, 768-PositionY, 768, 400);
			[secondAd3 openView:NO];
		}
		else 
		{//세로
			secondAd3.view.frame = CGRectMake(0, 1024-PositionY, 768, 400);
			[secondAd3 openView:YES];
		}
		[secondAd3 openView:YES];
	}
	[self COMP2];
	
}

//2차 광고 닫기
//2차 광고 닫기 버튼이 눌린후 노티피케이션으로 호출,
//isAdOpne을 NO로 설정
-(void)closeAd{
	isAdOpen = NO;
}

//DM에서 키보드가 등장할때 위치 조정하기 위한 함수
-(void)showKeyBoard{
	[secondAd3 keyBordOpen:NO];
}

//DM에서 키보드가 사라질대 화면을 제자리로 돌리기 위해 호출됩니다.
-(void)hideKeyBoard{
	[secondAd3 keyBordClose:NO];
}

#pragma mark -
#pragma mark updateRotate //로테이션시 위치 조정
//가로 세로 전환에 대한 위치 조정, 
-(void)updateRotate{
	
	CGRect rect;
	rect = [[UIApplication sharedApplication] statusBarFrame];

	
	//if ([self.type isEqualToString:@"DACPM03"])
	if([self.type isEqualToString:@"DACPM04"])
	{
		if(isToastOpen)
		{
			UIDeviceOrientation orientation = [UIApplication sharedApplication].statusBarOrientation; 
			if (orientation == UIDeviceOrientationLandscapeLeft || orientation == UIDeviceOrientationLandscapeRight) 
			{
				self.view.frame = CGRectMake(128,768-bannerHeight-PositionY,  768, bannerHeight);
			}
			else 
			{
				self.view.frame = CGRectMake(0,1024-bannerHeight-PositionY,  768, bannerHeight);
			}
			
		}
		else 
		{
			UIDeviceOrientation orientation = [UIApplication sharedApplication].statusBarOrientation; 
			if (orientation == UIDeviceOrientationLandscapeLeft || orientation == UIDeviceOrientationLandscapeRight) 
			{
				self.view.frame = CGRectMake(128,768-rect.size.width-30-PositionY,  768, bannerHeight);
			}
			else 
			{
				self.view.frame = CGRectMake(0,1024-rect.size.height-30-PositionY,  768, bannerHeight);
			}			
		}		

	}
	else {
		
		bannerHeight = 72;
		UIDeviceOrientation orientation = [UIApplication sharedApplication].statusBarOrientation; 
		if (orientation == UIDeviceOrientationLandscapeLeft || orientation == UIDeviceOrientationLandscapeRight) 
		{//가로
			
			self.view.frame = CGRectMake(128,768-rect.size.width-bannerHeight-PositionY,  768, bannerHeight);
			
			if (isAdOpen) 
			{
				secondAd1.view.frame = CGRectMake(128, 768-PositionY-320, 768, 768);
				secondAd2.view.frame = CGRectMake(128, 768-PositionY-380, 768, 768);
				secondAd3.view.frame = CGRectMake(128, 768-PositionY-480, 768, 400);
			}


		}
		else 
		{
			self.view.frame = CGRectMake(0,1024-rect.size.height-bannerHeight-PositionY,  768, bannerHeight);
			
			if (isAdOpen) 
			{
				secondAd1.view.frame = CGRectMake(0, 1024-PositionY-320, 768, 768);
				secondAd2.view.frame = CGRectMake(0, 1024-PositionY-380, 768, 768);
				secondAd3.view.frame = CGRectMake(0, 1024-PositionY-480, 768, 400);
			}

		}
	}
}

#pragma mark -
#pragma mark sendTo Server // 서버 통지
-(void)CLICK1
{
	NSString* phoneUDID = [[UIDevice currentDevice] uniqueIdentifier];
	phoneUDID = [phoneUDID stringByReplacingOccurrencesOfString:@"-" withString:@""];
	NSString* reqURL = url_confirm;
	reqURL = [reqURL stringByAppendingFormat:@"slotId=%@",m_slotID];
	reqURL = [reqURL stringByAppendingFormat:@"&adId=%@",self.adId];
	reqURL = [reqURL stringByAppendingFormat:@"&eventType=CLICK1"];
	reqURL = [reqURL stringByAppendingFormat:@"&deviceId=%@",phoneUDID];
	reqURL = [reqURL stringByAppendingFormat:@"&deviceType=SP"];
	reqURL = [reqURL stringByAppendingFormat:@"&osType=IO"];
	reqURL = [reqURL stringByAppendingFormat:@"&osVer=4"];
	reqURL = [reqURL stringByAppendingFormat:@"&model="];
	reqURL = [reqURL stringByAppendingFormat:@"&browserNm="];
	reqURL = [reqURL stringByAppendingFormat:@"&deviceTime="];
	reqURL = [reqURL stringByAppendingFormat:@"&ip=%@",u_ip];
	reqURL = [reqURL stringByAppendingFormat:@"&areaCd="];
	reqURL = [reqURL stringByAppendingFormat:@"&imgXSize=640"];
	reqURL = [reqURL stringByAppendingFormat:@"&imgYSize=960"];
	
	
	[self requestUrl:reqURL];
	//NSLog(@"click1  %@",reqURL);
	
}
-(void)CLICK2
{
	
	NSString* phoneUDID = [[UIDevice currentDevice] uniqueIdentifier];
	phoneUDID = [phoneUDID stringByReplacingOccurrencesOfString:@"-" withString:@""];
	NSString* reqURL = url_confirm;
	reqURL = [reqURL stringByAppendingFormat:@"slotId=%@",m_slotID];
	reqURL = [reqURL stringByAppendingFormat:@"&adId=%@",self.adId];
	reqURL = [reqURL stringByAppendingFormat:@"&eventType=CLICK2"];
	reqURL = [reqURL stringByAppendingFormat:@"&deviceId=%@",phoneUDID];
	reqURL = [reqURL stringByAppendingFormat:@"&deviceType=SP"];
	reqURL = [reqURL stringByAppendingFormat:@"&osType=IO"];
	reqURL = [reqURL stringByAppendingFormat:@"&osVer=4"];
	reqURL = [reqURL stringByAppendingFormat:@"&model="];
	reqURL = [reqURL stringByAppendingFormat:@"&browserNm="];
	reqURL = [reqURL stringByAppendingFormat:@"&deviceTime="];
	reqURL = [reqURL stringByAppendingFormat:@"&ip=%@",u_ip];
	reqURL = [reqURL stringByAppendingFormat:@"&areaCd="];
	reqURL = [reqURL stringByAppendingFormat:@"&imgXSize=640"];
	reqURL = [reqURL stringByAppendingFormat:@"&imgYSize=960"];
	
	[self requestUrl:reqURL];
	//NSLog(@"click2  %@",reqURL);
}
-(void)COMP1
{
	
	NSString* phoneUDID = [[UIDevice currentDevice] uniqueIdentifier];
	phoneUDID = [phoneUDID stringByReplacingOccurrencesOfString:@"-" withString:@""];
	NSString* reqURL = url_confirm;
	reqURL = [reqURL stringByAppendingFormat:@"slotId=%@",m_slotID];
	reqURL = [reqURL stringByAppendingFormat:@"&adId=%@",self.adId];
	reqURL = [reqURL stringByAppendingFormat:@"&eventType=COMP1"];
	reqURL = [reqURL stringByAppendingFormat:@"&deviceId=%@",phoneUDID];
	reqURL = [reqURL stringByAppendingFormat:@"&deviceType=SP"];
	reqURL = [reqURL stringByAppendingFormat:@"&osType=IO"];
	reqURL = [reqURL stringByAppendingFormat:@"&osVer=4"];
	reqURL = [reqURL stringByAppendingFormat:@"&model="];
	reqURL = [reqURL stringByAppendingFormat:@"&browserNm="];
	reqURL = [reqURL stringByAppendingFormat:@"&deviceTime="];
	reqURL = [reqURL stringByAppendingFormat:@"&ip=%@",u_ip];
	reqURL = [reqURL stringByAppendingFormat:@"&areaCd="];
	reqURL = [reqURL stringByAppendingFormat:@"&imgXSize=640"];
	reqURL = [reqURL stringByAppendingFormat:@"&imgYSize=960"];
	
	[self requestUrl:reqURL];
	//NSLog(@"comp1  %@",reqURL);
}
-(void)COMP2
{
	NSString* phoneUDID = [[UIDevice currentDevice] uniqueIdentifier];
	phoneUDID = [phoneUDID stringByReplacingOccurrencesOfString:@"-" withString:@""];
	NSString* reqURL = url_confirm;
	reqURL = [reqURL stringByAppendingFormat:@"slotId=%@",m_slotID];
	reqURL = [reqURL stringByAppendingFormat:@"&adId=%@",self.adId];
	reqURL = [reqURL stringByAppendingFormat:@"&eventType=COMP2"];
	reqURL = [reqURL stringByAppendingFormat:@"&deviceId=%@",phoneUDID];
	reqURL = [reqURL stringByAppendingFormat:@"&deviceType=SP"];
	reqURL = [reqURL stringByAppendingFormat:@"&osType=IO"];
	reqURL = [reqURL stringByAppendingFormat:@"&osVer=4"];
	reqURL = [reqURL stringByAppendingFormat:@"&model="];
	reqURL = [reqURL stringByAppendingFormat:@"&browserNm="];
	reqURL = [reqURL stringByAppendingFormat:@"&deviceTime="];
	reqURL = [reqURL stringByAppendingFormat:@"&ip=%@",u_ip];
	reqURL = [reqURL stringByAppendingFormat:@"&areaCd="];
	reqURL = [reqURL stringByAppendingFormat:@"&imgXSize=640"];
	reqURL = [reqURL stringByAppendingFormat:@"&imgYSize=960"];
	
	
	[self requestUrl:reqURL];
	//NSLog(@"comp2  %@",reqURL);
}
//위에서 구성된 URL로 서버에 통지를 날립니다. NSURLConnection에 의해서 중간에 데이터를 받고 에러에 대한 리스너는 파싱하는 부분과 공통으로 사용됩니다.
//다만, 통지에 대해서는 특별한 처리를 하지 않습니다.
- (BOOL)requestUrl:(NSString *)url {
	// URL 접속 초기화
	isSendData = YES;
	NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url] 
														   cachePolicy:NSURLRequestUseProtocolCachePolicy 
													   timeoutInterval:15.0]; 
	
	// GET 방식
	[request setHTTPMethod:@"GET"];
	
	
	NSURLConnection *connection = [[NSURLConnection alloc] initWithRequest:request delegate:self];
	if (connection) { 
		
		return YES;
	}
	
	return NO;
}
#pragma mark -
#pragma mark view Life cycle //기본 템플릿 함수
//템플릿으로 제공 되는 함수들
- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
    [super dealloc];
}


@end
