

#import <UIKit/UIKit.h>


@interface AdBanner : UIViewController {
	
	//터치,토스트,콜,디엠에서 배경 이미지로 쓰일 배너 이미지
	UIImageView* adImage; 
	
	//토스트 배너가 열려 있는지 판별하는값
	BOOL isOpen;
	
	
	//롤링배너의 배너 이미지들을 담는 배열
	NSMutableArray* arrAdImages;

    //롤링배너에서 아래로 내려가는 이미지 
	UIImageView* frontImage;
    //롤링 배너에서 위에서 내료오는 이미지
	UIImageView* backImage;
    //이미지의 갯수
	int maxImages;
    //현재 롤링배너에서 몇번째 이미지인지 저장해 놓는 값
	int k;
	
	//공통
	NSString* adType;
}
//하단 배너의 이미지를 셋팅
-(void)setAdImage:(UIImage*)image;

//롤링배너의 경우 이미지가 여러개 이므로 배열로 이미지를 셋팅
-(void)setAdImages:(NSMutableArray*)Images;

//배너의 타입에 따라 하단의 띠배너를 셋팅 
-(id)initWithAdType:(NSString*)stradType;

//롤링배너를 돌리기 위한 타이머
-(void)timerStart;

//롤링배너중 현재 배너의 인덱스를 가져오기 위한 함수 
-(int)getBannerIndex;

@end
